//
//  Created by Tom Baranes on 24/11/15.
//  Copyright © 2015 Tom Baranes. All rights reserved.
//

import UIKit

final class LocalizablesExampleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.translateSubviews()
    }

}

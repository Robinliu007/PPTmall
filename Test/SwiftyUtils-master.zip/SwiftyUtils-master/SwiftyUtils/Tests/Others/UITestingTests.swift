//
//  Created by Tom Baranes on 14/07/16.
//  Copyright © 2016 Tom Baranes. All rights reserved.
//

import Foundation
import XCTest
import SwiftyUtils

final class UITestingTests: XCTestCase {

    func testIsRunning() {
        XCTAssertFalse(UITesting.isRunning)
    }

}

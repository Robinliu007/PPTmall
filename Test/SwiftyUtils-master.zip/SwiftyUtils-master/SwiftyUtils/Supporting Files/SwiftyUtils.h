//
//  Created by Tom Baranes on 24/04/16.
//  Copyright © 2016 Tom Baranes. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftyUtils.
FOUNDATION_EXPORT double SwiftyUtilsVersionNumber;

//! Project version string for SwiftyUtils.
FOUNDATION_EXPORT const unsigned char SwiftyUtilsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyUtils/PublicHeader.h>


